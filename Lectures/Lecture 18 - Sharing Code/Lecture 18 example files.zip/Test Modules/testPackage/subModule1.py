# -*- coding: utf-8 -*-
"""
Aidan Hunt
5/23/2023

This module defines several constants (attributes).
"""

attribute1 = 5
attribute2 = 'hello'
attribute3 = False