# -*- coding: utf-8 -*-
"""
This example module defines several simple functions for performing 
mathematical operations on two numbers.
"""

def addNums(num1, num2):
    return num1 + num2

def subtractNums(num1, num2):
    return num1 - num2

def multiplyNums(num1, num2):
    return num1 * num2

def divideNums(num1, num2):
    return num1 * num2