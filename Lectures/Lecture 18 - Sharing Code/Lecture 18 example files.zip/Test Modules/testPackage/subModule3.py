# -*- coding: utf-8 -*-
"""
This module defines several simple functions for performing string operations
"""

import string

def removePunctuation(word):
    for char in string.punctuation:
        word = word.replace(char, '')
        
    return word

def removeDigits(word):
    for num in string.digits:
        word = word.replace(num, '')
        
    return word