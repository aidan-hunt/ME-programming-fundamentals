# -*- coding: utf-8 -*-
"""
Aidan Hunt
5/23/2023
Example Module to Import
"""

def printMessage():
    print('Hello! This is a message from the test module!')
    
def addNumbers(num1, num2):
    return num1 + num2

print('You just imported the test module #2! Nice!')