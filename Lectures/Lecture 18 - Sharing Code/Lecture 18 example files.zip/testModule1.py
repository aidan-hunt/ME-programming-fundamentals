# -*- coding: utf-8 -*-
"""
This is a module that is in the same folder as our main script
"""

var1 = 1
var2 = 2
var3 = 3

def printWordLength(word):
    print(word, 'has', len(word), 'characters in it.')
    
print('Hello from test module #1!')
